//
//  QuinoaIOS.h
//  QuinoaIOS
//
//  Created by dan bright on 5/29/15.
//  Copyright (c) 2015 sense360. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for QuinoaIOS.
FOUNDATION_EXPORT double QuinoaIOSVersionNumber;

//! Project version string for QuinoaIOS.
FOUNDATION_EXPORT const unsigned char QuinoaIOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QuinoaIOS/PublicHeader.h>


